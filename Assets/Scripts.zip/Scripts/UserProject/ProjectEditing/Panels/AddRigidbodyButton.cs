using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AddRigidbodyButton : MonoBehaviour
{
    public bool isRigidbody = false;
    public ModeType modeType;
    public SelectionManager selectionManager;
    private GameObject curSelect;
}
